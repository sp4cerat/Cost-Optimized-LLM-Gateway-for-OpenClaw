# LLM Gateway v1.3

**Kostenoptimiertes AI-Routing für OpenClaw**

> Hetzner + Groq Router + Prompt Caching = **73% Kostenreduktion**
> 
> Monatliche Kosten: **~€25-30** statt €92 (AWS-Baseline)

## Features

### Dreistufiges Routing
| Tier | Modell | Use-Case | Kosten |
|------|--------|----------|--------|
| **CACHE_ONLY** | - | Zu vage, Rückfrage | €0 |
| **CHEAP** | Llama 3.1 8B (Groq) | Einfache Erklärungen | ~€0.05/1M |
| **PREMIUM** | Claude Sonnet | Komplexe Analyse, Code | ~€3-15/1M |

### Zweistufiges Caching
- **Exact Cache**: SHA-256 Hash, O(1) Lookup
- **Semantic Cache**: Embedding-basiert, Similarity Search

### Sicherheit
- **Hard Policy Gate**: Blockiert rm -rf, Secrets, Injections
- **Rate Limiting**: Token-aware, per Tier
- **Budget Guard**: Soft → Medium → Hard Limits
- **Kill Switch**: Throttle → Degrade → Kill

### Kostenoptimierung
- **Prompt Caching**: 90% Rabatt auf System-Prompts (Anthropic)
- **BM25 Fast-Path**: Keyword-Search vor teuren Embeddings
- **Context Budgeting**: Token-Limits pro Tier
- **Risk-Stratified Verifier**: Spart Verifikations-Calls

## Quick Start

### Option 1: Docker (Empfohlen)

```bash
# Clone
git clone https://github.com/your-org/llm-gateway.git
cd llm-gateway

# Configure
cp config/.env.example .env
# Edit .env with your API keys

# Start
docker-compose up -d

# Test
curl http://localhost:8000/health
```

### Option 2: Hetzner Setup

```bash
# SSH to your Hetzner CX22 server
ssh root@your-server-ip

# Download and run setup
curl -fsSL https://your-domain.com/setup-gateway.sh | bash

# Or clone and run manually
git clone https://github.com/your-org/llm-gateway.git
cd llm-gateway
chmod +x scripts/setup-gateway.sh
./scripts/setup-gateway.sh --full
```

### Option 3: Manual Installation

```bash
# Install dependencies
apt install python3 python3-pip python3-venv nginx

# Create environment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Configure
cp config/.env.example .env
# Edit .env

# Run
uvicorn main:app --host 0.0.0.0 --port 8000
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `GROQ_API_KEY` | Groq API Key (Router) | Required |
| `ANTHROPIC_API_KEY` | Anthropic API Key (Premium) | Required |
| `OPENAI_API_KEY` | OpenAI Key (Embeddings) | Optional |
| `GATEWAY_SECRET` | API Auth Token | Required |
| `DAILY_BUDGET_SOFT` | Warning threshold | $5 |
| `DAILY_BUDGET_MEDIUM` | Premium throttle | $15 |
| `DAILY_BUDGET_HARD` | Block all | $50 |

### Budget Limits

```
$0 ────────────────────────────────────────────> Daily Spend

     NORMAL        SOFT         MEDIUM          HARD
   [Full Speed] [Warning]  [Premium Block] [All Block]
        |           |             |              |
       $0         $5.00        $15.00         $50.00
```

## API Reference

### Chat Completions

```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Authorization: Bearer YOUR_GATEWAY_SECRET" \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role": "user", "content": "Explain async/await in Python"}
    ],
    "temperature": 0.7,
    "max_tokens": 1024
  }'
```

**Response:**
```json
{
  "id": "req_1234567890",
  "model": "groq/llama-3.1-8b",
  "choices": [{
    "message": {
      "role": "assistant",
      "content": "Async/await in Python..."
    }
  }],
  "usage": {
    "prompt_tokens": 10,
    "completion_tokens": 150,
    "total_tokens": 160
  },
  "gateway_meta": {
    "latency_ms": 234,
    "source": "cheap",
    "routing": {
      "tier": "CHEAP",
      "confidence": 0.92
    }
  }
}
```

### Health Check

```bash
curl http://localhost:8000/health
```

### Metrics

```bash
curl -H "Authorization: Bearer YOUR_SECRET" http://localhost:8000/metrics
```

### Budget Status

```bash
curl -H "Authorization: Bearer YOUR_SECRET" http://localhost:8000/budget
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                          REQUEST FLOW                            │
└─────────────────────────────────────────────────────────────────┘

  Request
     │
     ▼
┌─────────────┐
│ Policy Gate │ ──── BLOCK ───► 403 (rm -rf, secrets)
└─────────────┘
     │ PASS
     ▼
┌─────────────┐
│ Rate Limit  │ ──── BLOCK ───► 429 (Too Many Requests)
└─────────────┘
     │ PASS
     ▼
┌─────────────┐
│ Budget Guard│ ──── BLOCK ───► 429 (Budget Exceeded)
└─────────────┘
     │ PASS
     ▼
┌─────────────┐
│ Exact Cache │ ──── HIT ─────► Response (€0)
└─────────────┘
     │ MISS
     ▼
┌─────────────┐
│Semantic Cache│ ── HIT+Verify ► Response (€0.001)
└─────────────┘
     │ MISS
     ▼
┌─────────────┐
│ Groq Router │
│ (Llama 8B)  │
└─────────────┘
     │
     ├── CACHE_ONLY ──► "Bitte präzisieren"
     ├── CHEAP ───────► Groq Llama (€0.05/1M)
     └── PREMIUM ─────► Claude Sonnet (€3-15/1M)
                              │
                              ▼
                    ┌─────────────────┐
                    │ Prompt Caching  │ -90% System-Prompt
                    └─────────────────┘
                              │
                              ▼
                         Response
                              │
                              ▼
                    ┌─────────────────┐
                    │  Cache Store    │
                    └─────────────────┘
```

## Cost Breakdown

| Komponente | Berechnung | Monatlich |
|------------|------------|-----------|
| Hetzner CX22 | €4,35 fix | €4,35 |
| Groq Router | 15k Req × 300 Tok | €0,25 |
| Embeddings | 5k Queries | €1,00 |
| Haiku (Cheap) | 10k Req | €5,00 |
| Sonnet (Premium) | 3k Req | €12,60 |
| Prompt Cache Rabatt | | -€2,43 |
| **TOTAL** | | **~€21** |

## Development

### Running Tests

```bash
# Install dev dependencies
pip install pytest pytest-asyncio

# Run tests
pytest tests/ -v
```

### Local Development

```bash
# With hot reload
uvicorn main:app --reload --port 8000

# With debug logging
LOG_LEVEL=DEBUG uvicorn main:app --reload
```

## Troubleshooting

### High Premium Rate (>30%)

```bash
# Check router decisions
grep "routing" /var/log/llm-gateway/gateway.log | jq '.routing.tier' | sort | uniq -c
```

Adjust router prompts if too many queries route to premium.

### Low Cache Hit Rate (<20%)

1. Check semantic threshold (try 0.90 instead of 0.92)
2. Verify BM25 index is building
3. Check for high query variance

### Budget Alerts

```bash
# Check current spend
curl -H "Authorization: Bearer $TOKEN" localhost:8000/budget

# Adjust limits in .env
DAILY_BUDGET_SOFT=10.0
DAILY_BUDGET_MEDIUM=30.0
DAILY_BUDGET_HARD=100.0
```

## License

MIT License - See LICENSE file

## Credits

- **OpenClaw Team** - Architecture & Implementation
- **Anthropic** - Claude Models & Prompt Caching
- **Groq** - Fast Inference for Routing
